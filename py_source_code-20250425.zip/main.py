from Lab4 import *
from Lab6 import *

class Perform_The_Task(object):
    def Perform_The_lab_4_1(self):
        result = Lab4()
        result.task_1()

    def Perform_The_lab_4_2(self):
        result = Lab4()
        result.task_2()

    def Perform_The_lab_6_1(self):
        result = Lab6()
        result.task_1()

    def Perform_The_lab_6_2(self):
        result = Lab6()
        result.task_2()



if __name__ == '__main__':
    Perform_The_Task().Perform_The_lab_6_2()
